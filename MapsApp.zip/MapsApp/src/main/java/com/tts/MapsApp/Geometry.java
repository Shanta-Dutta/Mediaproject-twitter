package com.tts.MapsApp;

import lombok.Data;

@Data
public class Geometry {
	private Location location;
}
